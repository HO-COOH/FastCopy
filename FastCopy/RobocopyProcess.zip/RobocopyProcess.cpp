﻿#include "pch.h"
#include "RobocopyProcess.h"
#include "RobocopyArgs.h"
#include "RobocopyInjectDll.h"
#include <wil/resource.h>
#include "Ntdll.h"

namespace bp = boost::process::v2;
namespace asio = boost::asio;

void RobocopyProcess::runContext()
{
	static bool v = [] {
		std::thread
		{
			[] 
			{
				ios.run();
			}
		}.detach();
		return true;
	}();
}

std::regex& RobocopyProcess::progressRegex()
{
	static std::regex Progress{ "^[0-9]+[.]?[0-9]*%" };
	return Progress;
}

void RobocopyProcess::injectProcess()
{
	auto& path = RobocopyInjectDll::Path();
	std::wcout << L"Injecting dll: " << path << L'\n';
	auto child_pid = m_child.id();
	auto child_handle = m_child.native_handle();
	auto pathSize = (path.size() + 1) * sizeof(wchar_t);

	// GET PROCESS FIRST/MAIN THREAD HANDLE
	if (!m_mainThread)
	{
        std::wcerr << L"[E] main thread handle not captured\n";
		return;
	}

	LPVOID remoteMem = VirtualAllocEx(
		child_handle,
		NULL,
		pathSize,
		MEM_COMMIT,
		PAGE_READWRITE
	);

	if (!remoteMem)
		return;

	// WRITE DLL PATH
	if (!WriteProcessMemory(child_handle, remoteMem, path.c_str(), pathSize, NULL))
		return;

	// INJECT THE DLL (QueueUserAPC)
	// We use QueueUserAPC instead of CreateRemoteThread because the process is suspended.
	// CreateRemoteThread can deadlock if the loader lock is held or not initialized.
	// The APC will execute when the main thread resumes and initializes.
	auto loadLibraryAddr = RobocopyInjectDll::LoadLibraryAddr();
	if (loadLibraryAddr)
	{
		QueueUserAPC(
			reinterpret_cast<PAPCFUNC>(loadLibraryAddr),
			m_mainThread.get(),
			reinterpret_cast<ULONG_PTR>(remoteMem)
		);
	}

	// RESUME THE TARGET
	// Now that the APC is queued, we let the actual application run.
	// The APC will fire early in the initialization of the process.
	std::cout << "Resuming application..." << std::endl;
	ResumeThread(m_mainThread.get());

	// Note: Handles (pi.hProcess, pi.hThread) are managed by boost::process::child (m_child).
	// We should not close them manually here.
}

void RobocopyProcess::WaitForExit()
{
	//ios.run();
	m_child.wait();
	std::cout << "Child exit with code: " << m_child.native_exit_code() << '\n';
}
