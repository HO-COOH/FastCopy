﻿#pragma once

#include <regex>
#include <iostream>

#include "../SpeedTest/Process.h"
#include "RobocopyArgs.h"
#include "NewFile.h"
#include "NewDir.h"
#include "Same.h"
#include "Conflict.h"
#include "ExistingDir.h"
#include "RobocopyProcessStatus.h"

#include <boost/asio.hpp>
#include <boost/regex.hpp>
#ifndef BOOST_PROCESS_V2_HEADER_ONLY
#define BOOST_PROCESS_V2_HEADER_ONLY
#endif
#include <boost/process/v2.hpp>      // v2 总头
#include <wil/resource.h>

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <shellapi.h> // CommandLineToArgvW

//Forward declaration
struct RobocopyArgs;
class RobocopyArgsBuilder;

// 为了少写名字，弄两个别名
namespace bp = boost::process::v2;
namespace asio = boost::asio;

/**
 * @brief Represents a robocopy process
 */
class RobocopyProcess
{
    // v2 推荐 io_context
    static inline asio::io_context ios;
    static inline auto work = asio::make_work_guard(ios);
    constexpr static auto k_OutBufferSize = MAX_PATH + 20;

    // v2 使用 asio 的 pipe
    asio::readable_pipe pipeOut{ ios };

    // v2 的 process
    bp::process m_child;

    // 主线程句柄 + tid（用于 QueueUserAPC / ResumeThread）
    wil::unique_handle m_mainThread;
    DWORD              m_mainTID = 0;

    static void runContext();
    static std::regex& progressRegex();

    void injectProcess();

    // --- 工具：把 builder.Build() 返回的 wchar_t 命令行拆成 UTF-8 argv ---
    static std::vector<std::string> build_args_utf8(const RobocopyArgsBuilder& builder)
    {
        // 原来 v1 是: cmd( search_path(L"robocopy.exe").wstring() + L" " + builder.Build() )
        // 这里我们自己拼一条 Windows 风格命令行，然后用 CommandLineToArgvW 拆成 argv
        std::wstring full_cmd = L"robocopy.exe ";
        full_cmd += builder.Build();   // Build() 应该只返回参数那一部分

        int argc = 0;
        LPWSTR* argv = ::CommandLineToArgvW(full_cmd.c_str(), &argc);
        std::vector<std::string> utf8_args;

        if (!argv || argc <= 1)
        {
            if (argv) ::LocalFree(argv);
            return utf8_args;
        }

        auto to_utf8 = [](std::wstring_view w) -> std::string
            {
                if (w.empty())
                    return {};

                int needed = ::WideCharToMultiByte(
                    CP_UTF8, 0,
                    w.data(), static_cast<int>(w.size()),
                    nullptr, 0, nullptr, nullptr);

                std::string result(needed, '\0');
                ::WideCharToMultiByte(
                    CP_UTF8, 0,
                    w.data(), static_cast<int>(w.size()),
                    result.data(), needed,
                    nullptr, nullptr);

                return result;
            };

        // argv[0] 是 "robocopy.exe"，我们只要后面的参数
        for (int i = 1; i < argc; ++i)
        {
            utf8_args.emplace_back(to_utf8(argv[i]));
        }

        ::LocalFree(argv);
        return utf8_args;
    }

    // --- v2 初始化器：在 CreateProcess 成功后捕获主线程句柄 ---
    struct captureMainThread
    {
        wil::unique_handle* out_handle;
        DWORD* out_tid;

        template<typename Launcher>
        void on_success(Launcher& launcher,
            const bp::filesystem::path&,
            std::wstring&) const
        {
            // windows::default_launcher 里有 PROCESS_INFORMATION process_information
            *out_tid = launcher.process_information.dwThreadId;

            HANDLE dup = nullptr;
            HANDLE self = ::GetCurrentProcess();

            if (::DuplicateHandle(
                self,
                launcher.process_information.hThread,
                self,
                &dup,
                THREAD_SET_CONTEXT |
                THREAD_SUSPEND_RESUME |
                THREAD_QUERY_INFORMATION,
                FALSE,
                0))
            {
                out_handle->reset(dup);
            }
            else
            {
                // 这里可以加日志
            }
        }
    };

    // --- v2 初始化器：让进程以 CREATE_SUSPENDED 启动 ---
    struct create_suspend
    {
        template<typename Launcher>
        boost::system::error_code
            on_setup(Launcher& launcher,
                const bp::filesystem::path&,
                std::wstring&)
        {
            launcher.creation_flags |= CREATE_SUSPENDED;
            return {};
        }
    };

public:
    template<typename OnProgress,
        typename OnNewFile,
        typename OnNewFolder,
        typename OnSame,
        typename OnConfict,
        typename OnExistingDir,
        typename OnProcessExit>
    RobocopyProcess(RobocopyArgsBuilder const& builder,
        OnProgress    onProgress,
        OnNewFile     onNewFile,
        OnNewFolder   onNewFolder,
        OnSame        onSame,
        OnConfict     onConfict,
        OnExistingDir onExistingDir,
        OnProcessExit onProcessExit)
        : pipeOut(ios)
        , m_child(
            // 1) executor
            ios,
            // 2) 可执行文件路径（UTF-8，v2 会自己用 conv_string 转成宽字串）
            L"robocopy.exe", /// FIXME: 这里 v2 没有 search_path。
            // 3) 参数列表（UTF-8）
            build_args_utf8(builder),
            // 4) stdio: 只抓 stdout 到 pipeOut，其它默认
            bp::process_stdio{ .in = nullptr,
                               .out = pipeOut,
                               .err = nullptr },
            // 5) 不创建窗口
            /*bp::windows::create_no_window,*/
            // 6) 挂上 CREATE_SUSPENDED
            create_suspend{},
            // 7) 记录主线程句柄 + tid
            captureMainThread{ &m_mainThread, &m_mainTID }
        )
    {
        // 此时子进程已经处于挂起状态，m_mainThread 已经指向主线程句柄
        injectProcess();

        SetConsoleCP(65001);
        SetConsoleOutputCP(65001);
        runContext();

        // 和你原来一样的协程读 stdout 部分，只是命名空间换成 asio/bp
        asio::co_spawn(
            ios,
            [this,
            onProgress = std::move(onProgress),
            onNewFile = std::move(onNewFile),
            onNewFolder = std::move(onNewFolder),
            onSame = std::move(onSame),
            onConflict = std::move(onConfict),
            onExistingDir = std::move(onExistingDir),
            onProcessExit = std::move(onProcessExit)]()
            -> asio::awaitable<void>
            {
                auto onProgressCopy = std::move(onProgress);
                auto onNewFileCopy = std::move(onNewFile);
                auto onNewFolderCopy = std::move(onNewFolder);
                auto onProcessExitCopy = std::move(onProcessExit);
                auto onSameCopy = std::move(onSame);
                auto onConflictCopy = std::move(onConflict);
                auto onExistingDirCopy = std::move(onExistingDir);
                auto thisCopy = this;

                std::vector<char> outBuf(k_OutBufferSize);

                try
                {
                    auto buf = asio::dynamic_buffer(outBuf);
                    while (true)
                    {
                        auto n = co_await asio::async_read_until(
                            thisCopy->pipeOut,
                            buf,
                            boost::regex{ "\r|\n" },
                            asio::use_awaitable);

                        std::string_view data{ outBuf.data(),
                                               outBuf.data() + n };
                        std::cout << data << '\n';

                        // trim 前后空白
                        auto first = data.find_first_not_of(" \r\t");
                        if (first == std::string_view::npos)
                        {
                            buf.consume(n);
                            continue;
                        }
                        auto last = data.find_last_not_of(" \r\n\t");
                        data.remove_prefix(first);
                        data.remove_suffix(data.size() - 1 - last);

                        if (!data.empty())
                        {
                            if (data.starts_with(NewFile::Prefix))
                            {
                                if (auto nf = NewFile::TryParse(data))
                                    onNewFileCopy(std::move(*nf));
                            }
                            else if (data.starts_with(NewDir::Prefix))
                            {
                                if (auto nd = NewDir::TryParse(data))
                                    onNewFolderCopy(std::move(*nd));
                            }
                            else if (data.starts_with(Same::Prefix))
                            {
                                if (auto s = Same::TryParse(data))
                                    onSameCopy(std::move(*s));
                            }
                            else if (std::ranges::any_of(
                                Conflict::Prefix,
                                [&data](auto prefix)
                                {
                                    return data.starts_with(
                                        prefix);
                                }))
                            {
                                if (auto c = Conflict::TryParse(data))
                                    onConflictCopy(std::move(*c));
                            }
                            else if (auto exDir =
                                ExistingDir::TryParse(data))
                            {
                                onExistingDirCopy(std::move(*exDir));
                            }
                            else if (std::regex_match(
                                data.data(),
                                data.data() + data.size(),
                                progressRegex()))
                            {
                                onProgressCopy(
                                    std::strtof(data.data(), nullptr));
                            }
                        }

                        buf.consume(n);
                    }
                }
                catch (const boost::system::system_error& e)
                {
                    if (auto code = e.code();
                        code == asio::error::eof ||
                        code == asio::error::broken_pipe)
                    {
                        onProcessExitCopy();
                    }
                }
                catch (const std::exception& e)
                {
                    std::cerr << "[E]: " << e.what() << '\n';
                }
            },
            asio::detached);
    }

    // v2::basic_process::native_handle() 不是 const，所以这里不能是 const
    HANDLE Handle() { return m_child.native_handle(); }

    void WaitForExit();
};

/**
 * @brief Represents the status of a invoke
 */
enum class Status
{
    Running,
    Pause,
    Cancel
};

//https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy#exit-return-codes
enum class RoboCopyExitCodes
{
    //No files were copied. No failure was encountered. No files were mismatched. The files already exist in the destination directory; therefore, the copy operation was skipped.
    NoCopy = 0,

    //All files were copied successfully.
    Success = 1,

    //There are some additional files in the destination directory that aren't present in the source directory. No files were copied.
    NoCopyExtraFiles = 2,

    //Some files were copied. Additional files were present. No failure was encountered.
    PartialCopyExtraFiles = 3,

    //Some files were copied. Some files were mismatched. No failure was encountered.
    PartialCopyMismatchFiles = 5,

    //Additional files and mismatched files exist. No files were copied and no failures were encountered meaning that the files already exist in the destination directory.
    NoCopyExtraFilesAndMismatchFiles = 6,

    //Files were copied, a file mismatch was present, and additional files were present.
    PartialCopyExtraFilesAndMismatchedFiles = 7,

    //Several files didn't copy.
    PartialError = 8
};